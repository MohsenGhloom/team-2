<?php
	session_start();
    //admin login setup
	include("../../admincon.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Record Biography Information</title>

     <!-- STYLE -->
     <link rel="stylesheet" href="../../css/nav.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

    <!-- FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Kameron:wght@400..700&display=swap" rel="stylesheet">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div>
        <!-- navbar to show admin name and email -->
        <div class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid text-light">
				<span><strong>Welcome: <?php echo $_SESSION['name'];?></strong></span>
				<span><strong>Email: <?php echo $_SESSION['email'];?></strong></span>
				<ul class="nav navbar-nav navbar-right">
					<li class="nav-item text-light">
						<a class="nav-link" href="../../logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</div>
        <!-- main form container -->
        <div class="container-fluid my-5">
            <div class="row">
                <div class="col-md-12">
                    <a href="../view/biography.php"><button class="btn border-dark">Back</button></a>
                    <h4 class="text-center">Add Reocrds - Biography Information</h4>
                </div>
            </div>

            <div>
                <!-- form to add records -->
                <form action="" method="POST" class="form-horizontal" enctype="multipart/form-data">
                    <div class="row m-5"> 
                        <div class="col-sm-1">
                            <label for="mobile">ID</label>
                            <input type="text" name="bioinfo_id[] sl" id="bioinfo_id"  class="form-control"  readonly>
                        </div>	
                        <div class="col-sm-2">
                            <label for="mobile">Forename</label>
                            <input type="text" name="forename[] sl" id="forename"  class="form-control"  required>
                        </div>
                        <div class="col-sm-2">
                            <label for="email">Surname</label>
                            <input type="text" name="surname[]" id="surname" class="form-control" required>
                        </div>
                        <div class="col-sm-2">
                            <label for="mobile">Regiment</label>
                            <input type="text" name="regiment[]" id="regiment" class="form-control" required>
                        </div>
                        <div class="col-sm-2">
                            <label for="mobile">Service Number</label>
                            <input type="text" name="service_no[]" id="service_no" class="form-control" required>
                        </div>    
                        <div class="col-sm-1">
                            <label for="">File upload</label>
                            <input type="file" name="file[]" id="file">
                        </div>
                    </div>
                    <div id="next"></div>
                    <button type="button" name="addrow" id="addrow" class="btn btn-success pull-right">Add New Row</button>
                    <button type="submit" name="submit" class="btn btn-info pull-left">Submit</button>
                </form>
            </div>
        </div>

        <!-- script yo Add multiple records at once -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            $('#addrow').click(function () { 
            var length = $('.sl').length;
            var i =parseInt(length)+parseInt(1);
            var newrow = $('#next').append('<div class="row m-5"><div class="col-sm-1"><label for="mobile">ID</label><input type="text" name="bioinfo_id[] sl" id="bioinfo_id"  class="form-control"  readonly></div><div class="col-sm-2"> <label for="mobile">Forename</label> <input type="text" name="forename[] sl" id="forename'+i+'"  class="form-control"  required> </div> <div class="col-sm-2"> <label for="email">Surname</label> <input type="text" name="surname[]" id="surname'+i+'" class="form-control" required> </div> <div class="col-sm-2"> <label for="mobile">Regiment</label> <input type="text" name="regiment[]" id="regiment'+i+'" class="form-control" required> </div> <div class="col-sm-2"> <label for="mobile">Service Number</label> <input type="text" name="service_no[]" id="service_no'+i+'" class="form-control" required> </div> <div class="col-sm-1"> <label for="">File upload</label> <input type="file" name="file[]" id="file'+i+'"> </div><div class="col-sm-2">  <button type="button" name="remove" id="remove" class="btnRemove float-right btn-danger ms-3">Remove</button></div> </div>')
            });
            //delete the row
            $('body').on('click','.btnRemove',function () { 
            // alert('pressed');
            $(this).closest('.row').remove()
            });
        </script>
    </div>
</body>
</html>
<?php
    if(isset($_POST['submit']))
	{
        $severname = 'localhost';
        $username = "root";
        $password = "";
        try{
            $con = new PDO("mysql:host=$severname;dbname=bradford",$username,$password);
            $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $e){
            echo '<br>' .$e->getMessage();
        } 
        for ($i= 0; $i <count($_POST['bioinfo_id']) ; $i++  ) { 
            $surname    = $_POST['surname'][$i];
            $forename   = $_POST['forename'][$i];
            $regiment   = $_POST['regiment'][$i];
            $service_no = $_POST['service_no'][$i];
            // for file upload
            $pname  = rand(1000, 10000)."-".$_FILES["file"]["name"][$i];
	        $tname = $_FILES["file"]["tmp_name"][$i];
            $uploads_dir = '../uploads';
            move_uploaded_file($tname, $uploads_dir.'/'.$pname);
            if( $surname!=='' && $forename!=='' && $regiment!=='' && $service_no!=='' && $pname!=='')
            {
                $sql = "INSERT INTO bf_biography_info(surname, forename, regiment, service_no, biography) VALUES('$surname','$forename','$regiment','$service_no','$pname')";
                $stmt = $con->prepare($sql);
                $stmt->execute();
            }
	        else
            {
                echo '<div class="alert alert-danger" role="alert">Error Submitting in Data</div>';
            }
        }
        echo "<script type='text/javascript'>";
        echo "window.location.href = '../view/biography.php';";
		echo "alert('Submitted successfully')";

		echo "</script>";
    }
?>