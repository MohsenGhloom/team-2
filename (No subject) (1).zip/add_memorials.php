<?php
	session_start();
	//admin login setup
	include("../../admincon.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Bradford Memorials</title>

     <!-- STYLE -->
     <link rel="stylesheet" href="../../css/nav.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

    <!-- FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Kameron:wght@400..700&display=swap" rel="stylesheet">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
	<div>
        <!-- navbar ro show admin name and email -->
	    <div class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid text-light">
				<span><strong>Welcome: <?php echo $_SESSION['name'];?></strong></span>
				<span><strong>Email: <?php echo $_SESSION['email'];?></strong></span>
				<ul class="nav navbar-nav navbar-right">
					<li class="nav-item text-light">
						<a class="nav-link" href="../../logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</div>

        <!-- main form container -->
		<div class="container-fluid my-5">
            <div class="row">
                <div class="col-md-12">
                    <a href="../view/memorials.php"><button class="btn border-dark">Back</button></a>
                    <h4 class="text-center">Add Records - Bradford Memorials</h4>
                </div>
            </div>
            <div>
                <form action="" method="POST" class="form-horizontal">
                    <div class="rem">
                        <div class="row">
                            <div class="col-sm-1 mt-2">
                                <label for="texxt">ID</label>
                                <input type="text" name="mem_id[]" id ="mem_id sl" class="form-control" readonly>
                            </div>
                            <div class="col-sm-2 mt-2">
                                <label for="email">Surname</label>
                                <input type="text" name="surname[]" id ="surname" class="form-control" required>
                            </div>
                            <div class="col-sm-2 mt-2">
                                <label for="mobile">Forename</label>
                                <input type="text" name="forename[]" id ="forename" class="form-control" required>
                            </div>
                            <div class="col-sm-2 mt-2">
                                <label for="mobile">Regiment</label>
                                <input type="text" name="regiment[]" id ="regiment" class="form-control" required>
                            </div>
                            <div class="col-sm-2 mt-2">
                                <label for="mobile">Unit</label>
                                <input type="text" name="unit[]" id ="unit" class="form-control" required>
                            </div>
                        
                            <div class="col-sm-2 mt-2">
                                <label for="mobile">Memorial</label>
                                <input type="text" name="memorial"[]  id ="memorial" class="form-control" required>
                            </div>
                            </div>
                        <div class="row">
                            <div class="col-sm-2 mt-2">
                                <label for="mobile">Memorial Address:</label>
                                <input type="text" name="memorial_address[]" id ="memorial_address" class="form-control" required>
                            </div>
                            <div class="col-sm-2 mt-2">
                                <label for="mobile">Memorial Location</label>
                                <input type="text" name="memorial_location[]" id ="memorial_location" class="form-control" required>
                            </div>
                            <div class="col-sm-2 mt-2">
                                <label for="mobile">Memorial Post Code</label>
                                <input type="text" name="memorial_post_code[]" id ="memorial_post_code" class="form-control" required>
                            </div>
                            <div class="col-sm-2 mt-2">
                                <label for="mobile">District</label>
                                <input type="text" name="district[]" id ="district" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <div id="next"></div>
                    <button type="button" name="addrow" id="addrow" class="btn btn-success mt-4">Add New Row</button>
                    <button type="submit" name="submit" class="btn btn-info mt-4">Submit</button>
			    </form>   
            </div>
            
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            //adding new row
            $('#addrow').click(function () { 
                var length = $('.sl').length;
                var i =parseInt(length)+parseInt(1);
                var newrow = $('#next').append('<div class="rem"> <div class="row"> <div class="col-sm-1 mt-2"> <label for="text">ID</label><input type="text" name="mem_id[]" id ="mem_id sl" class="form-control" readonly></div><div class="col-sm-2 mt-2"> <label for="email">Surname</label> <input type="text" name="surname[]" id ="surname sl'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Forename</label> <input type="text" name="forename[]" id ="forename'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Regiment</label> <input type="text" name="regiment[]" id ="regiment'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Unit</label> <input type="text" name="unit[]" id ="unit'+i+'" class="form-control" required> </div>  <div class="col-sm-2 mt-2"> <label for="mobile">Memorial</label> <input type="text" name="memorial"[]  id ="memorial'+i+'" class="form-control" required> </div> </div> <div class="row"><div class="col-sm-2 mt-2"> <label for="mobile">Memorial Address:</label> <input type="text" name="memorial_address[]" id ="memorial_address'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Memorial Location</label> <input type="text" name="memorial_location[]" id ="memorial_location'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Memorial Post Code</label> <input type="text" name="memorial_post_code[]" id ="memorial_post_code'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">District</label> <input type="text" name="district[]" id ="district'+i+'" class="form-control" required> </div> <div class="col-sm-2"><button type="button" name="remove" id="remove" class="btnRemove btn-danger mt-4">Remove</button></div></div> </div>')
            });
            //delete the row
            $('body').on('click','.btnRemove',function () { 
                // alert('pressed');
                $(this).closest('.rem').remove()
            });
        </script>    
    </div>
</body>
</html>
<?php
	//check whether the database is connected or not
	if(isset($_POST['submit']))
	{
		$severname = 'localhost';
		$username = "root";
		$password = "";
		//checking the connections to database
		try{
			$con = new PDO("mysql:host=$severname;dbname=bradford",$username,$password);
			$con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		}
		catch(PDOException $e){
			echo '<br>' .$e->getMessage();
		}
		for ($i= 0; $i <count($_POST['mem_id']) ; $i++  ){

			$surname = $_POST['surname'][$i];
			$forename = $_POST['forename'][$i];
			$regiment = $_POST['regiment'][$i];
			$unit = $_POST['unit'][$i];
			$memorial = $_POST['memorial'][$i];
			$memorial_address = $_POST['memorial_address'][$i];
			$memorial_location = $_POST['memorial_location'][$i];
			$memorial_post_code = $_POST['memorial_post_code'][$i];
			$district = $_POST['district'][$i];
			{
				if(
					$surname !== '' &&
					$forename !== '' &&
					$regiment !== '' &&
					$unit !== '' &&
					$memorial !== '' &&
					$memorial_address !== '' &&
					$memorial_location !== '' &&
					$memorial_post_code !== '' &&
					$district !== ''
				){
					$sql ="INSERT INTO bf_memorials(surname,forename,regiment,unit,memorial,memorial_address,memorial_location,memorial_post_code,district) VALUES(
						
					'$surname',
					'$forename',
					'$regiment',
					'$unit',
					'$memorial',
					'$memorial_address',
					'$memorial_location',
					'$memorial_post_code',
					'$district'

					)";
					$stmt = $con->prepare($sql);
					$stmt->execute();
				}
				else
			   {
					echo '<div class="alert alert-danger" role="alert">Error Submitting in Data</div>';
			   }
			}
		echo "<script type='text/javascript'>";
        echo "window.location.href = '../view/memorials.php';";
		echo "alert('Submitted successfully')";
		echo "</script>";
		}

	}



?>
