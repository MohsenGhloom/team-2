<?php
	session_start();
	//admin login setup
	include("../../admincon.php");

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Newspaper References</title>

     <!-- STYLE -->
     <link rel="stylesheet" href="../../css/nav.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

    <!-- FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Kameron:wght@400..700&display=swap" rel="stylesheet">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
	
<body>
    <div>
	<!-- navbar ro show admin name and email -->
	    <div class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid text-light">
				<span><strong>Welcome: <?php echo $_SESSION['name'];?></strong></span>
				<span><strong>Email: <?php echo $_SESSION['email'];?></strong></span>
				<ul class="nav navbar-nav navbar-right">
					<li class="nav-item text-light">
						<a class="nav-link" href="../../logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</div>

    <!-- main form container -->
		<div class="container-fluid my-5">
            <div class="row">
                <div class="col-md-12">
                    <a href="../view/newspaper.php"><button class="btn border-dark">Back</button></a>
                    <h4 class="text-center">Add Records - Newspaper References</h4>
                </div>
            </div>

            <div>
            <form action="" method="POST" class="form-horizontal">
                    <div class="rem">
                        <div class="row">
                                <div class="col-sm-1 mt-2">
                                    <label for="mobile">ID</label>
                                    <input type="text" name="nr_id[]" id = "nr_id sl" class="form-control"  readonly>
                                </div>
                        </div>
                        <div class="row">
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Name</label>
                                    <input type="text" name="name[]" id = "name" class="form-control"  required>
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="email">Rank</label>
                                    <input type="text" name="rank[]" id = "rank" class="form-control"  required>								
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Age</label>
                                    <input type="text" name="age[]" id = "age" class="form-control" required>
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Address</label>
                                    <input type="text" name="address[]" id = "address" class="form-control" required>
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Regiment</label>
                                    <input type="text" name="regiment[]" id = "regiment" class="form-control" required>
                                </div>

                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Comment Category</label>
                                    <input type="text" name="comment_catagory[]" id = "comment_catagory" class="form-control" required>
                                </div>
                        </div>
                        <div class="row">
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Comment Data</label>
                                    <input type="text" name="comment_data[]" id = "comment_data" class="form-control" required>
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Comment Date</label>
                                    <input type="text" name="comment_date[]" id = "comment_date" class="form-control" required>
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Newspaper Name</label>
                                    <input type="text" name="newspaper_name[]" id = "newspaper_name" class="form-control" required>
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Paper Date</label>
                                    <input type="text" name="paper_date[]" id = "paper_date" class="form-control" required>
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Page/Col</label>
                                    <input type="text" name="page_col[]" id = "page_col" class="form-control" required>
                                </div>
                                <div class="col-sm-2 mt-2">
                                    <label for="mobile">Photo</label>
                                    <input type="text" name="photo[]" id = "photo" class="form-control" required>
                                </div>
                        </div>
                    </div>
                    <div id="next"></div>
                    <button type="button" name="addrow" id="addrow" class="btn btn-success mt-4">Add New Row</button>
                    <button type="submit" name="submit" class="btn btn-info mt-4">Submit</button>
            </form>
            </div>
        </div>
        <!-- script yo Add multiple records at once -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            //adding new row
            $('#addrow').click(function () { 
                var length = $('.sl').length;
                var i =parseInt(length)+parseInt(1);
                var newrow = $('#next').append('<div class="rem"> <div class="row"> <div class="col-sm-1 mt-2"> <label for="mobile">ID</label> <input type="text" name="nr_id[]" id = "nr_id sl" class="form-control"  readonly> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Name</label> <input type="text" name="name[]" id = "name'+i+'" class="form-control"  required> </div> <div class="col-sm-2 mt-2"> <label for="email">Rank</label> <input type="text" name="rank[]" id = "rank'+i+'" class="form-control"  required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Age</label> <input type="text" name="age[]" id = "age'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Address</label> <input type="text" name="address[]" id = "address'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Regiment</label> <input type="text" name="regiment[]" id = "regiment'+i+'" class="form-control" required> </div> </div> <div class="row"><div class="col-sm-2 mt-2"><label for="mobile">Comment Data</label><input type="text" name="comment_data[]" id = "comment_data'+i+'" class="form-control" required></div> <div class="col-sm-2 mt-2"> <label for="mobile">Comment Category</label> <input type="text" name="comment_catagory[]" id = "comment_catagory'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Comment Date</label> <input type="text" name="comment_date[]" id = "comment_date'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Newspaper Name</label> <input type="text" name="newspaper_name[]" id = "newspaper_name'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Paper Date</label> <input type="text" name="paper_date[]" id = "paper_date'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Page/Col</label> <input type="text" name="page_col[]" id = "page_col'+i+'" class="form-control" required> </div> <div class="col-sm-2 mt-2"> <label for="mobile">Photo</label> <input type="text" name="photo[]" id = "photo'+i+'" class="form-control" required> </div> <div class="col-sm-2"><button type="button" name="remove" id="remove" class="btnRemove btn-danger mt-4">Remove</button></div> </div> </div>')
            });
            //delete the row
            $('body').on('click','.btnRemove',function () { 
                // alert('pressed');
                $(this).closest('.rem').remove()
            });
        </script>
			
    </div>
</body>
</html>

<?php
//check whether the database is connected or not
	if(isset($_POST['submit']))
	{
		$severname = 'localhost';
		$username = "root";
		$password = "";
		//checking the connections to database
		try{
			$con = new PDO("mysql:host=$severname;dbname=bradford",$username,$password);
			$con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		}
		catch(PDOException $e){
			echo '<br>' .$e->getMessage();
		}
		for ($i= 0; $i <count($_POST['nr_id']) ; $i++  )
		{
			$name = $_POST['name'][$i];
			$rank = $_POST['rank'][$i];
			$age = $_POST['age'][$i];
			$address = $_POST['address'][$i];
			$regiment = $_POST['regiment'][$i];
			$comment_catagory = $_POST['comment_catagory'][$i];
			$comment_date = $_POST['comment_date'][$i];
			$comment_data = $_POST['comment_data'][$i];
			$newspaper_name = $_POST['newspaper_name'][$i];
			$paper_date = $_POST['paper_date'][$i];
			$page_col = $_POST['page_col'][$i];
			$photo = $_POST['photo'][$i];
			{
				if(
					$name !== '' &&
					$rank !== '' &&
					$age !== '' &&
					$address !== '' &&
					$regiment !== '' &&
					$comment_catagory !== '' &&
					$comment_date !== '' &&
					$comment_data !== '' &&
					$newspaper_name !== '' &&
					$paper_date !== '' &&
					$page_col !== '' &&
					$photo !== ''
				){
					$sql ="INSERT INTO bf_np_ref(name,rank,age,address,regiment,comment_catagory,comment_date,comment_data,newspaper_name,paper_date,page_col,photo) VALUES(

					'$name',
					'$rank',
					'$age',
					'$address',
					'$regiment',
					'$comment_catagory',
					'$comment_date',
					'$comment_data',
					'$newspaper_name',
					'$paper_date',
					'$page_col',
					'$photo'

					)";
					$stmt = $con->prepare($sql);
					$stmt->execute();
				}
				else
			   {
					echo '<div class="alert alert-danger" role="alert">Error Submitting in Data</div>';
			   }
			}
            // displaying message after adding records
			echo "<script type='text/javascript'>";
            echo "window.location.href = '../view/newspaper.php';";
			echo "alert('Submitted successfully')";
			echo "</script>";
		}
	}
?>
