<?php
	session_start();
	//admin login setup
	include("../../admincon.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Roll of Honor</title>

     <!-- STYLE -->
     <link rel="stylesheet" href="../../css/nav.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

    <!-- FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Kameron:wght@400..700&display=swap" rel="stylesheet">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<body>
    <div>
	<!-- navbar ro show admin name and email -->
	    <div class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid text-light">
				<span><strong>Welcome: <?php echo $_SESSION['name'];?></strong></span>
				<span><strong>Email: <?php echo $_SESSION['email'];?></strong></span>
				<ul class="nav navbar-nav navbar-right">
					<li class="nav-item text-light">
						<a class="nav-link" href="../../logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</div>

    <!-- main form container -->
		<div class="container-fluid my-5">
            <div class="row">
                <div class="col-md-12">
                    <a href="../view/warroll.php"><button class="btn border-dark">Back</button></a>
                    <h4 class="text-center">Add Records - War Rolls of Honor</h4>
                </div>
            </div>

            <div>
                <form action="" method="POST" class="form-horizontal">
                    <div class="rem">
                                <div class="row">        
                                    <div class="col-sm-2 mt-2">
                                        <label>ID</label>
                                        <input type="text" name="roll_id[]" id="roll_id sl" class="form-control" readonly>
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Gender</label>
                                        <input type="text" name="gender[]" id="gender" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Surname</label>
                                        <input type="text" name="surname[]" id="surname" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Forename</label>
                                        <input type="text" name="forename[]" id="forename" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Address</label>
                                        <input type="text" name="address[]" id="address" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Electoral Ward</label>
                                        <input type="text" name="elec_ward[]" id="elec_ward" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Town</label>
                                        <input type="text" name="town[]" id="town" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Rank</label>
                                        <input type="text" name="rank[]" id="rank" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Regiment</label>
                                        <input type="text" name="reg[]" id="reg" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Unit</label>
                                        <input type="text" name="unit[]" id="unit" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Company</label>
                                        <input type="text" name="company[]" id="company" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Other Regiment</label>
                                        <input type="text" name="other_reg[]" id="other_reg" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Other Unit</label>
                                        <input type="text" name="other_unit[]" id="other_unit" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Other Company</label>
                                        <input type="text" name="other_com[]" id="other_com" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>British Medal (1)</label>
                                        <input type="text" name="bm1[]" id="bm1" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>British Medal (2)</label>
                                        <input type="text" name="bm2[]" id="bm2" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Certificates</label>
                                        <input type="text" name="certificates[]" id="certificates" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Mentioned (1)</label>
                                        <input type="text" name="men1[]" id="men1" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Mentioned (2)</label>
                                        <input type="text" name="men2[]" id="men2" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Forign Medal (1)</label>
                                        <input type="text" name="fm1[]" id="fm1" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Forign Medal (2)</label>
                                        <input type="text" name="fm2[]" id="fm2" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Enlistment Date</label>
                                        <input type="text" name="enlist_date[]" id="enlist_date" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Enlistment Date Format</label>
                                        <input type="text" name="elist_date_format[]" id="elist_date_format" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Discharged Date Format</label>
                                        <input type="text" name="discharge_dare_format[]" id="discharge_dare_format" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Discharged Date</label>
                                        <input type="text" name="discharge_date[]" id="discharge_date" class="form-control">    
                                    </div>

                                    <div class="col-sm-2 mt-2">
                                        <label>Death in Service Format</label>
                                        <input type="text" name="death_ser_format[]" id="death_ser_format" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Death(in service) Date</label>
                                        <input type="text" name="death_ser_date[]" id="death_ser_date" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Misc Norh Info</label>
                                        <input type="text" name="misc_norh_info[]" id="misc_norh_info" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Age</label>
                                        <input type="text" name="age[]" id="age" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Service No.</label>
                                        <input type="text" name="ser_no[]" id="ser_no" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Other Service No.</label>
                                        <input type="text" name="other_ser_no[]" id="other_ser_no" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Cemetery/Memorial</label>
                                        <input type="text" name="cem_mem[]" id="cem_mem" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Cemetery Memorial Ref</label>
                                        <input type="text" name="cem_mem_ref[]" id="cem_mem_ref" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Cemetery/Memorial Country</label>
                                        <input type="text" name="cem_mem_country[]" id="cem_mem_country" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Additional CWGC Info</label>
                                        <input type="text" name="add_cwcg_ifo[]" id="add_cwcg_ifo" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Occupation</label>
                                        <input type="text" name="occupation[]" id="occupation" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Munitions factory worker</label>
                                        <input type="text" name="mun_factory_worker[]" id="mun_factory_worker" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Rejoined after discharged</label>
                                        <input type="text" name="rej_dis[]" id="rej_dis" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Death cause unknown</label>
                                        <input type="text" name="death_unknown[]" id="death_unknown" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Kia</label>
                                        <input type="text" name="kia[]" id="kia" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Died of gas poisoning</label>
                                        <input type="text" name="dgas_poision[]" id="dgas_poision" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Died in captivity</label>
                                        <input type="text" name="dcapt[]" id="dcapt" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Ship Sank Survived</label>
                                        <input type="text" name="shipsunk_sur[]" id="shipsunk_sur" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Ship Sank-died</label>
                                        <input type="text" name="dship_sank[]" id="dship_sank" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Accidental Death</label>
                                        <input type="text" name="daccident[]" id="daccident" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Died of Wounds</label>
                                        <input type="text" name="dwounds[]" id="dwounds" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Died of illness</label>
                                        <input type="text" name="dillness[]" id="dillness" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Served at home</label>
                                        <input type="text" name="ser_athome[]" id="ser_athome" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Served at home(ill health)</label>                                 
                                        <input type="text" name="ser_athome_ill[]" id="ser_athome_ill" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Served at home(unfit)</label>                                    
                                        <input type="text" name="ser_athome_unfit[]" id="ser_athome_unfit" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Western Front</label>                                    
                                        <input type="text" name="western_front[]" id="western_front" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Balkans</label>                                    
                                        <input type="text" name="balkans[]" id="balkans" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Dardanelles/Gallipoli</label>                                    
                                        <input type="text" name="dard_gall[]" id="dard_gall" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Egypt/Palestine</label>                                    
                                        <input type="text" name="egy_pal[]" id="egy_pal" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Mesopotamia</label>                                    
                                        <input type="text" name="meso[]" id="meso" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Salonika</label>                                    
                                        <input type="text" name="salonika[]" id="salonika" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>East Africa</label>                                    
                                        <input type="text" name="east_africa[]" id="east_africa" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Italy</label>                                    
                                        <input type="text" name="italy[]" id="italy" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Malta</label>                                    
                                        <input type="text" name="malta[]" id="malta" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Isle of man</label>                                    
                                        <input type="text" name="isle_man[]" id="isle_man" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Ireland</label>                                    
                                        <input type="text" name="ireland[]" id="ireland" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>India</label>                                    
                                        <input type="text" name="india[]" id="india" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Russia</label>                                    
                                        <input type="text" name="russia[]" id="russia" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>At Sea</label>                                    
                                        <input type="text" name="at_sea[]" id="at_sea" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Persia</label>                                    
                                        <input type="text" name="persia[]" id="persia" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Army of occupation -Turkey</label>                                    
                                        <input type="text" name="occ_turkey[]" id="occ_turkey" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Army of occupation -Germany</label>                                    
                                        <input type="text" name="occ_germany[]" id="occ_germany" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Wounded during service</label>                                    
                                        <input type="text" name="wds1[]" id="wds1" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Wounded during service x2</label>                                    
                                        <input type="text" name="wds2[]" id="wds2" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Wounded during service 3+</label>                                    
                                        <input type="text" name="wds3[]" id="wds3" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Gassed during service</label>                                    
                                        <input type="text" name="gds[]" id="gds" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Loss oflimb</label>                                    
                                        <input type="text" name="limb[]" id="limb" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>loss of speech</label>                                    
                                        <input type="text" name="speech[]" id="speech" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>loss of sight</label>                                    
                                        <input type="text" name="sight[]" id="sight" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Shell shock</label>                                    
                                        <input type="text" name="shell_shock[]" id="shell_shock" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>ship sank-Survived</label>                                    
                                        <input type="text" name="sship_sank[]" id="sship_sank" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Dischaged-shell shock</label>                                    
                                        <input type="text" name="dishell_shock[]" id="dishell_shock" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Discharged-wounded</label>
                                        <input type="text" name="diswound[]" id="diswound" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Discharged-gas</label>
                                        <input type="text" name="disgassed[]" id="disgassed" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Dischaged-ill health</label>
                                        <input type="text" name="disill[]" id="disill" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Discharged-physically unfit</label>
                                        <input type="text" name="disphyunfit[]" id="disphyunfit" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Discharged-medically unfit</label>
                                        <input type="text" name="dismedunfit[]" id="dismedunfit" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Unfit for overseas</label>
                                        <input type="text" name="unfit_overseas[]" id="unfit_overseas" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Overage/Underage</label>
                                        <input type="text" name="over_under_age[]" id="over_under_age" class="form-control">    
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-sm-2 mt-2">
                                        <label>Son claimed out</label>
                                        <input type="text" name="son_claim[]" id="son_claim" class="form-control">    
                                    </div>
                                    <div class="col-sm-2 mt-2">
                                        <label>Captured</label> 
                                        <input type="text" name="captured[]" id="captured" class="form-control">                     
                                    </div>
                                </div>
                    </div>
                    <div id="next"></div>
                    <button type="button" name="addrow" id="addrow" class="btn btn-success mt-4">Add New Row</button>
                    <button type="submit" name="submit" class="btn btn-info mt-4">Submit</button>
                </form>
            </div>
        </div>
        <!-- script yo Add multiple records at once -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            //adding new row
            $('#addrow').click(function () { 
                var length = $('.sl').length;
                var i =parseInt(length)+parseInt(1);
                var newrow = $('#next').append(' <div class="rem"> <div class="row"> <div class="col-sm-2 mt-2"> <label>ID</label> <input type="text" name="roll_id[]" id="roll_id sl" class="form-control" readonly> </div> <div class="col-sm-2 mt-2"> <label>Gender</label> <input type="text" name="gender[]" id="gender'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Surname</label> <input type="text" name="surname[]" id="surname'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Forename</label> <input type="text" name="forename[]" id="forename'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Address</label> <input type="text" name="address[]" id="address'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Electoral Ward</label> <input type="text" name="elec_ward[]" id="elec_ward'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Town</label> <input type="text" name="town[]" id="town'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Rank</label> <input type="text" name="rank[]" id="rank'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Regiment</label> <input type="text" name="reg[]" id="reg'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Unit</label> <input type="text" name="unit[]" id="unit'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Company</label> <input type="text" name="company[]" id="company'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Other Regiment</label> <input type="text" name="other_reg[]" id="other_reg'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Other Unit</label> <input type="text" name="other_unit[]" id="other_unit'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Other Company</label> <input type="text" name="other_com[]" id="other_com'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>British Medal (1)</label> <input type="text" name="bm1[]" id="bm1'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>British Medal (2)</label> <input type="text" name="bm2[]" id="bm2'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Certificates</label> <input type="text" name="certificates[]" id="certificates'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Mentioned (1)</label> <input type="text" name="men1[]" id="men1'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Mentioned (2)</label> <input type="text" name="men2[]" id="men2'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Forign Medal (1)</label> <input type="text" name="fm1[]" id="fm1'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Forign Medal (2)</label> <input type="text" name="fm2[]" id="fm2'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Enlistment Date</label> <input type="text" name="enlist_date[]" id="enlist_date'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Enlistment Date Format</label> <input type="text" name="elist_date_format[]" id="elist_date_format'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Discharged Date Format</label> <input type="text" name="discharge_dare_format[]" id="discharge_dare_format'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Discharged Date</label> <input type="text" name="discharge_date[]" id="discharge_date'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Death in Service Format</label> <input type="text" name="death_ser_format[]" id="death_ser_format'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Death(in service) Date</label> <input type="text" name="death_ser_date[]" id="death_ser_date'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Misc Norh Info</label> <input type="text" name="misc_norh_info[]" id="misc_norh_info'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Age</label> <input type="text" name="age[]" id="age'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Service No.</label> <input type="text" name="ser_no[]" id="ser_no'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Other Service No.</label> <input type="text" name="other_ser_no[]" id="other_ser_no'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Cemetery/Memorial</label> <input type="text" name="cem_mem[]" id="cem_mem'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Cemetery Memorial Ref</label> <input type="text" name="cem_mem_ref[]" id="cem_mem_ref'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Cemetery/Memorial Country</label> <input type="text" name="cem_mem_country[]" id="cem_mem_country'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Additional CWGC Info</label> <input type="text" name="add_cwcg_ifo[]" id="add_cwcg_ifo'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Occupation</label> <input type="text" name="occupation[]" id="occupation'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Munitions factory worker</label> <input type="text" name="mun_factory_worker[]" id="mun_factory_worker'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Rejoined after discharged</label> <input type="text" name="rej_dis[]" id="rej_dis'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Death cause unknown</label> <input type="text" name="death_unknown[]" id="death_unknown'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Kia</label> <input type="text" name="kia[]" id="kia'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Died of gas poisoning</label> <input type="text" name="dgas_poision[]" id="dgas_poision'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Died in captivity</label> <input type="text" name="dcapt[]" id="dcapt'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Ship Sank Survived</label> <input type="text" name="shipsunk_sur[]" id="shipsunk_sur'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Ship Sank-died</label> <input type="text" name="dship_sank[]" id="dship_sank'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Accidental Death</label> <input type="text" name="daccident[]" id="daccident'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Died of Wounds</label> <input type="text" name="dwounds[]" id="dwounds'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Died of illness</label> <input type="text" name="dillness[]" id="dillness'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Served at home</label> <input type="text" name="ser_athome[]" id="ser_athome'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Served at home(ill health)</label> <input type="text" name="ser_athome_ill[]" id="ser_athome_ill'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Served at home(unfit)</label> <input type="text" name="ser_athome_unfit[]" id="ser_athome_unfit'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Western Front</label> <input type="text" name="western_front[]" id="western_front'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Balkans</label> <input type="text" name="balkans[]" id="balkans'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Dardanelles/Gallipoli</label> <input type="text" name="dard_gall[]" id="dard_gall'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Egypt/Palestine</label> <input type="text" name="egy_pal[]" id="egy_pal'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Mesopotamia</label> <input type="text" name="meso[]" id="meso'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Salonika</label> <input type="text" name="salonika[]" id="salonika'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>East Africa</label> <input type="text" name="east_africa[]" id="east_africa'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Italy</label> <input type="text" name="italy[]" id="italy'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Malta</label> <input type="text" name="malta[]" id="malta'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Isle of man</label> <input type="text" name="isle_man[]" id="isle_man'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Ireland</label> <input type="text" name="ireland[]" id="ireland'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>India</label> <input type="text" name="india[]" id="india'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Russia</label> <input type="text" name="russia[]" id="russia'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>At Sea</label> <input type="text" name="at_sea[]" id="at_sea'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Persia</label> <input type="text" name="persia[]" id="persia'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Army of occupation -Turkey</label> <input type="text" name="occ_turkey[]" id="occ_turkey'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Army of occupation -Germany</label> <input type="text" name="occ_germany[]" id="occ_germany'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Wounded during service</label> <input type="text" name="wds1[]" id="wds1'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Wounded during service x2</label> <input type="text" name="wds2[]" id="wds2'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Wounded during service 3+</label> <input type="text" name="wds3[]" id="wds3'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Gassed during service</label> <input type="text" name="gds[]" id="gds'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Loss oflimb</label> <input type="text" name="limb[]" id="limb'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>loss of speech</label> <input type="text" name="speech[]" id="speech'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>loss of sight</label> <input type="text" name="sight[]" id="sight'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Shell shock</label> <input type="text" name="shell_shock[]" id="shell_shock'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>ship sank-Survived</label> <input type="text" name="sship_sank[]" id="sship_sank'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Dischaged-shell shock</label> <input type="text" name="dishell_shock[]" id="dishell_shock'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Discharged-wounded</label> <input type="text" name="diswound[]" id="diswound'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Discharged-gas</label> <input type="text" name="disgassed[]" id="disgassed'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Dischaged-ill health</label> <input type="text" name="disill[]" id="disill'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Discharged-physically unfit</label> <input type="text" name="disphyunfit[]" id="disphyunfit'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Discharged-medically unfit</label> <input type="text" name="dismedunfit[]" id="dismedunfit'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Unfit for overseas</label> <input type="text" name="unfit_overseas[]" id="unfit_overseas'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Overage/Underage</label> <input type="text" name="over_under_age[]" id="over_under_age'+i+'" class="form-control"> </div> </div> <div class="row"> <div class="col-sm-2 mt-2"> <label>Son claimed out</label> <input type="text" name="son_claim[]" id="son_claim'+i+'" class="form-control"> </div> <div class="col-sm-2 mt-2"> <label>Captured</label> <input type="text" name="captured[]" id="captured'+i+'" class="form-control"> </div> <div class="col-sm-2"><button type="button" name="remove" id="remove" class="btnRemove border-dark mt-4">Remove</button></div> </div> </div>')
            });
            //delete the row
            $('body').on('click','.btnRemove',function () { 
                // alert('pressed');
                $(this).closest('.rem').remove()
            });
        </script>
    </div>  

</body>
</html>
<?php
if(isset($_POST['submit']))
{
    $severname = 'localhost';
    $username = "root";
    $password = "";
    //checking the connections to database
    try{
        $con = new PDO("mysql:host=$severname;dbname=bradford",$username,$password);
        $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e){
        echo '<br>' .$e->getMessage();
    }
    for ($i= 0; $i <count($_POST['roll_id']) ; $i++  )
    {
        $gender = $_POST['gender'][$i];
$surname = $_POST['surname'][$i];
$forename = $_POST['forename'][$i];
$address = $_POST['address'][$i];
$elec_ward = $_POST['elec_ward'][$i];
$town = $_POST['town'][$i];
$rank = $_POST['rank'][$i];
$reg = $_POST['reg'][$i];
$unit = $_POST['unit'][$i];
$company = $_POST['company'][$i];
$other_reg = $_POST['other_reg'][$i];
$other_unit = $_POST['other_unit'][$i];
$other_com = $_POST['other_com'][$i];
$bm1 = $_POST['bm1'][$i];
$bm2 = $_POST['bm2'][$i];
$certificates = $_POST['certificates'][$i];
$men1 = $_POST['men1'][$i];
$men2 = $_POST['men2'][$i];
$fm1 = $_POST['fm1'][$i];
$fm2 = $_POST['fm2'][$i];
$enlist_date = $_POST['enlist_date'][$i];
$elist_date_format = $_POST['elist_date_format'][$i];
$discharge_dare_format = $_POST['discharge_dare_format'][$i];
$discharge_date = $_POST['discharge_date'][$i];
$death_ser_format = $_POST['death_ser_format'][$i];
$death_ser_date = $_POST['death_ser_date'][$i];
$misc_norh_info = $_POST['misc_norh_info'][$i];
$age = $_POST['age'][$i];
$ser_no = $_POST['ser_no'][$i];
$other_ser_no = $_POST['other_ser_no'][$i];
$cem_mem = $_POST['cem_mem'][$i];
$cem_mem_ref = $_POST['cem_mem_ref'][$i];
$cem_mem_country = $_POST['cem_mem_country'][$i];
$add_cwcg_ifo = $_POST['add_cwcg_ifo'][$i];
$occupation = $_POST['occupation'][$i];
$mun_factory_worker = $_POST['mun_factory_worker'][$i];
$rej_dis = $_POST['rej_dis'][$i];
$death_unknown = $_POST['death_unknown'][$i];
$kia = $_POST['kia'][$i];
$dgas_poision = $_POST['dgas_poision'][$i];
$dcapt = $_POST['dcapt'][$i];
$shipsunk_sur = $_POST['shipsunk_sur'][$i];
$dship_sank = $_POST['dship_sank'][$i];
$daccident = $_POST['daccident'][$i];
$dwounds = $_POST['dwounds'][$i];
$dillness = $_POST['dillness'][$i];
$ser_athome = $_POST['ser_athome'][$i];
$ser_athome_ill = $_POST['ser_athome_ill'][$i];
$ser_athome_unfit = $_POST['ser_athome_unfit'][$i];
$western_front = $_POST['western_front'][$i];
$balkans = $_POST['balkans'][$i];
$dard_gall = $_POST['dard_gall'][$i];
$egy_pal = $_POST['egy_pal'][$i];
$meso = $_POST['meso'][$i];
$salonika = $_POST['salonika'][$i];
$east_africa = $_POST['east_africa'][$i];
$italy = $_POST['italy'][$i];
$malta = $_POST['malta'][$i];
$isle_man = $_POST['isle_man'][$i];
$ireland = $_POST['ireland'][$i];
$india = $_POST['india'][$i];
$russia = $_POST['russia'][$i];
$at_sea = $_POST['at_sea'][$i];
$persia = $_POST['persia'][$i];
$occ_turkey = $_POST['occ_turkey'][$i];
$occ_germany = $_POST['occ_germany'][$i];
$wds1 = $_POST['wds1'][$i];
$wds2 = $_POST['wds2'][$i];
$wds3 = $_POST['wds3'][$i];
$gds = $_POST['gds'][$i];
$limb = $_POST['limb'][$i];
$speech = $_POST['speech'][$i];
$sight = $_POST['sight'][$i];
$shell_shock = $_POST['shell_shock'][$i];
$sship_sank = $_POST['sship_sank'][$i];
$dishell_shock = $_POST['dishell_shock'][$i];
$diswound = $_POST['diswound'][$i];
$disgassed = $_POST['disgassed'][$i];
$disill = $_POST['disill'][$i];
$disphyunfit = $_POST['disphyunfit'][$i];
$dismedunfit = $_POST['dismedunfit'][$i];
$unfit_overseas = $_POST['unfit_overseas'][$i];
$over_under_age = $_POST['over_under_age'][$i];
$son_claim = $_POST['son_claim'][$i];
$captured = $_POST['captured'][$i];
{
    if(
        $gender !== '' &&
$surname !== '' &&
$forename !== '' &&
$address !== '' &&
$elec_ward !== '' &&
$town !== '' &&
$rank !== '' &&
$reg !== '' &&
$unit !== '' &&
$company !== '' &&
$other_reg !== '' &&
$other_unit !== '' &&
$other_com !== '' &&
$bm1 !== '' &&
$bm2 !== '' &&
$certificates !== '' &&
$men1 !== '' &&
$men2 !== '' &&
$fm1 !== '' &&
$fm2 !== '' &&
$enlist_date !== '' &&
$elist_date_format !== '' &&
$discharge_dare_format !== '' &&
$discharge_date !== '' &&
$death_ser_format !== '' &&
$death_ser_date !== '' &&
$misc_norh_info !== '' &&
$age !== '' &&
$ser_no !== '' &&
$other_ser_no !== '' &&
$cem_mem !== '' &&
$cem_mem_ref !== '' &&
$cem_mem_country !== '' &&
$add_cwcg_ifo !== '' &&
$occupation !== '' &&
$mun_factory_worker !== '' &&
$rej_dis !== '' &&
$death_unknown !== '' &&
$kia !== '' &&
$dgas_poision !== '' &&
$dcapt !== '' &&
$shipsunk_sur !== '' &&
$dship_sank !== '' &&
$daccident !== '' &&
$dwounds !== '' &&
$dillness !== '' &&
$ser_athome !== '' &&
$ser_athome_ill !== '' &&
$ser_athome_unfit !== '' &&
$western_front !== '' &&
$balkans !== '' &&
$dard_gall !== '' &&
$egy_pal !== '' &&
$meso !== '' &&
$salonika !== '' &&
$east_africa !== '' &&
$italy !== '' &&
$malta !== '' &&
$isle_man !== '' &&
$ireland !== '' &&
$india !== '' &&
$russia !== '' &&
$at_sea !== '' &&
$persia !== '' &&
$occ_turkey !== '' &&
$occ_germany !== '' &&
$wds1 !== '' &&
$wds2 !== '' &&
$wds3 !== '' &&
$gds !== '' &&
$limb !== '' &&
$speech !== '' &&
$sight !== '' &&
$shell_shock !== '' &&
$sship_sank !== '' &&
$dishell_shock !== '' &&
$diswound !== '' &&
$disgassed !== '' &&
$disill !== '' &&
$disphyunfit !== '' &&
$dismedunfit !== '' &&
$unfit_overseas !== '' &&
$over_under_age !== '' &&
$son_claim !== '' &&
$captured !== '' 
){
    $sql ="INSERT INTO bf_np_ref(gender,surname,forename,address,elec_ward,town,rank,reg,unit,company,other_reg,other_unit,other_com,bm1,bm2,certificates,men1,men2,fm1,fm2,enlist_date,elist_date_format,discharge_dare_format,discharge_date,death_ser_format,death_ser_date,misc_norh_info,age,ser_no,other_ser_no,cem_mem,cem_mem_ref,cem_mem_country,add_cwcg_ifo,occupation,mun_factory_worker,rej_dis,death_unknown,kia,dgas_poision,dcapt,shipsunk_sur,dship_sank,daccident,dwounds,dillness,ser_athome,ser_athome_ill,ser_athome_unfit,western_front,balkans,dard_gall,egy_pal,meso,salonika,east_africa,italy,malta,isle_man,ireland,india,russia,at_sea,persia,occ_turkey,occ_germany,wds1,wds2,wds3,gds,limb,speech,sight,shell_shock,sship_sank,dishell_shock,diswound,disgassed,disill,disphyunfit,dismedunfit,unfit_overseas,over_under_age,son_claim,captured) VALUES(
        '$gender',
'$surname',
'$forename',
'$address',
'$elec_ward',
'$town',
'$rank',
'$reg',
'$unit',
'$company',
'$other_reg',
'$other_unit',
'$other_com',
'$bm1',
'$bm2',
'$certificates',
'$men1',
'$men2',
'$fm1',
'$fm2',
'$enlist_date',
'$elist_date_format',
'$discharge_dare_format',
'$discharge_date',
'$death_ser_format',
'$death_ser_date',
'$misc_norh_info',
'$age',
'$ser_no',
'$other_ser_no',
'$cem_mem',
'$cem_mem_ref',
'$cem_mem_country',
'$add_cwcg_ifo',
'$occupation',
'$mun_factory_worker',
'$rej_dis',
'$death_unknown',
'$kia',
'$dgas_poision',
'$dcapt',
'$shipsunk_sur',
'$dship_sank',
'$daccident',
'$dwounds',
'$dillness',
'$ser_athome',
'$ser_athome_ill',
'$ser_athome_unfit',
'$western_front',
'$balkans',
'$dard_gall',
'$egy_pal',
'$meso',
'$salonika',
'$east_africa',
'$italy',
'$malta',
'$isle_man',
'$ireland',
'$india',
'$russia',
'$at_sea',
'$persia',
'$occ_turkey',
'$occ_germany',
'$wds1',
'$wds2',
'$wds3',
'$gds',
'$limb',
'$speech',
'$sight',
'$shell_shock',
'$sship_sank',
'$dishell_shock',
'$diswound',
'$disgassed',
'$disill',
'$disphyunfit',
'$dismedunfit',
'$unfit_overseas',
'$over_under_age',
'$son_claim',
'$captured'
    )";
    $stmt = $con->prepare($sql);
    $stmt->execute();
    }
    else
			   {
					echo '<div class="alert alert-danger" role="alert">Error Submitting in Data</div>';
			   }
}
    // displaying message after adding records
    echo "<script type='text/javascript'>";
    echo "window.location.href = '../view/warroll.php';";
    echo "alert('Submitted successfully')";
    echo "</script>";
    }
}

?>