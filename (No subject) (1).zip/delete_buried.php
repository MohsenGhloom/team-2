<?php
include('../../connect.php');

foreach($_POST["selector"] as $deleteId){
 $query = "delete from bf_buried where buried_id = $deleteId";

	
$query_run = mysqli_query($connection,$query);
}
echo '<script>alert("Data Deleted Successfully");</script>';
echo '<script>window.location.href = "../view/buried.php";</script>';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>